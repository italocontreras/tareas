
function changuelogin(elemento) {
    elemento.innerText = "Logout";
}

function deleteremoveadddefinition(elemento) {
    elemento.innerText = "";
}

function showalertlikes(elemento) {
    alert("Ninja was liked");

}