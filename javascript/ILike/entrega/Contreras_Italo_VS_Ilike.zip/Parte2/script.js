
function sumaLikes(parametro){
    var x = document.querySelector("#mg"+parametro);
    x.innerText++;
}