function sumaLikes(){
    var x = document.querySelector("span");
    x.innerText++;
    //x.innerText =  Number.parseInt(x.innerText) + 1;
}